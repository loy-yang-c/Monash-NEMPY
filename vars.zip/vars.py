# global params
START_DATE = "2026-01-03" # yyyy-mm-dd format
END_DATE = "2026-01-04" # excluding

DATA_PATH = r"C:\Users\rahee\OneDrive\文档\Monash-NEMPY"
MMS_DB_PATH = r"C:\Users\rahee\OneDrive\文档\nempy-backend"

# run_model.py params
NEMPY_MODEL = "nem_full - parallel.py" # reference a nempy model in ./models/
