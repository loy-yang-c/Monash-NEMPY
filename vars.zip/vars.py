# global params
START_DATE = "2023-12-05" # yyyy-mm-dd format
END_DATE = "2023-12-10" # excluding

DATA_PATH = r"C:\Users\rahee\OneDrive\文档\Monash-NEMPY"
MMS_DB_PATH = r"C:\dev\nempy-backend"
MMS_DB_WRITE_PATH = r"C:\dev\nempy-backend"
MMS_DB_WRITE_APNDX = ""
# save results outside of git as these files are large and LFS is expensive
RESULTS_PATH = r"C:\Users\rahee\OneDrive\文档\Loy-Yang-C\Paper 1\2. NEMPY\_tests"
CHUNK_START = 0

# run_model.py params
NEMPY_MODEL = "nem_full - parallel.py" # reference a nempy model in ./models/
N_JOBS = 12 # how many jobs at a time for parallel models  
MPC = 20300
MPF = -1000
SKIP_INTERVALS = ['2023/12/05 13:50:00', '2023/12/05 13:55:00'] #yyyy/dd/mm hh:mm:ss format