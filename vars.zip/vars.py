# global params
START_DATE = "2026-02-01" # yyyy-mm-dd format
END_DATE = "2026-03-01" # excluding

DATA_PATH = r"C:\Users\rahee\OneDrive\文档\Monash-NEMPY"

# run_model.py params
NEMPY_MODEL = "nem_full - parallel - VBB SIPS OFF.py" # reference a nempy model in ./models/

