# global params
START_DATE = "2026-01-01" # yyyy-mm-dd format
END_DATE = "2026-01-31" # excluding

DATA_PATH = r"C:\Users\rahee\OneDrive\文档\Monash-NEMPY"
MMS_DB_PATH = r"C:\dev\nempy-backend"
# save results outside of git as these files are large and LFS is expensive
RESULTS_PATH = r"C:\Users\rahee\OneDrive\文档\Loy-Yang-C\Paper 1\2. NEMPY\_tests"

# run_model.py params
NEMPY_MODEL = "nem_full - parallel.py" # reference a nempy model in ./models/
MPC = 20300
MPF = -1000