START_DATE = "2021-11-29" # yyyy-mm-dd format
END_DATE = "2022-01-01" # excluding

DOWNLOAD_INPUTS = False # for each machine, you only need to do this once for any specified date range

NEMPY_MODEL = "nem_full - parallel - VBB SIPS OFF.py" # reference a nempy model in ./models/